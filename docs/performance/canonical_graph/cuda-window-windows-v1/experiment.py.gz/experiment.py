"""Paired actual-window CUDA Adam benchmark, including compilation and input transfer."""
import os
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
from pathlib import Path
import hashlib
import json
import sys
import time

BASE = Path(__file__).resolve().parents[2]
TRAINER = BASE.parent / "PyRL-trainer"
sys.path.insert(0, str(TRAINER))
import torch
from pyrl_trainer.brain_artifact import HEADER, read_raw_brain_artifact
from pyrl_trainer.canonical_graph import CanonicalGraph, configure_distillation_precision
from pyrl_trainer.distillation_job import (DistillationJobConfig, admit_job_device,
    numerical_environment, trainer_source_sha256, SOURCE_FILES)
from pyrl_trainer.sequence_distillation import CanonicalSequenceTrainer, SequenceTrainingConfig
from pyrl_trainer.tactical_ablation import paired_windows, window_batch
from pyrl_trainer.tactical_corpus import load_tactical_corpus


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    torch.set_num_threads(2)
    configure_distillation_precision()
    device = admit_job_device(DistillationJobConfig(device="cuda:0", cpu_threads=2))
    torch.cuda.set_per_process_memory_fraction(8 * 1024**3 / torch.cuda.get_device_properties(device).total_memory, device)
    root = BASE / "native/target/heldout-curve-matrix-cuda-8000-20261022"
    blob = (root / "seed-1-fold-2/full/initial.slither-brain").read_bytes()
    _, manifest, _ = read_raw_brain_artifact(blob)
    weights = blob[HEADER.size + HEADER.unpack_from(blob)[1]:]
    corpus = load_tactical_corpus(root / "corpus")
    training, _ = corpus.split_by_seed({2})
    config = SequenceTrainingConfig()
    sources = {name: sha(TRAINER / "pyrl_trainer" / name) for name in SOURCE_FILES}
    reference = []
    result = {"schemaVersion":1, "kind":"paired-cuda-window-qualification",
              "scope":"32 paired actual native tactical windows; update timing excludes sampling and held-out evaluation, includes validation/transfer/compilation/Adam; not a gameplay, maturity or integrated throughput gate",
              "environment":numerical_environment(device), "trainerSourceSha256":trainer_source_sha256(),
              "nativeSourceSha256":corpus.source_sha256,
              "corpusManifestSha256":sha(root / "corpus/corpus.json"),
              "initialArtifactSha256":hashlib.sha256(blob).hexdigest(),
              "experimentSha256":sha(Path(__file__)), "sources":sources,
              "maxAbs":{name:0.0 for name in ("loss", "gradient", "weights", "state", "adamExpAvg", "adamExpAvgSq")},
              "runs":{}}
    for mode in ("eager", "cudagraphs"):
        model = CanonicalGraph(manifest, weights, device)
        trainer = CanonicalSequenceTrainer(model, config, cuda_graphs=mode == "cudagraphs")
        torch.cuda.reset_peak_memory_stats(device)
        cpu_rng, gpu_rng = torch.random.get_rng_state().clone(), torch.cuda.get_rng_state(device).clone()
        times = []
        previous = None
        for index, selected in enumerate(paired_windows(corpus, training, config, 32, 1)):
            batch, trainer.config = window_batch(corpus, manifest, selected, config)
            torch.cuda.synchronize(device)
            started = time.perf_counter()
            update = trainer.update(batch)
            torch.cuda.synchronize(device)
            times.append((time.perf_counter() - started) * 1000)
            adam = trainer.optimizer.state[model.flat_parameters]
            values = {"loss":torch.tensor(update.loss),
                      "gradient":model.flat_parameters.grad.detach().cpu().clone(),
                      "weights":model.flat_parameters.detach().cpu().clone(),
                      "state":update.next_state.detach().cpu().clone(),
                      "adamExpAvg":adam["exp_avg"].detach().cpu().clone(),
                      "adamExpAvgSq":adam["exp_avg_sq"].detach().cpu().clone()}
            if mode == "eager":
                reference.append(values)
            else:
                for name, value in values.items():
                    difference = (value - reference[index][name]).abs().max().item()
                    result["maxAbs"][name] = max(result["maxAbs"][name], difference)
                    torch.testing.assert_close(value, reference[index][name], atol=1e-6, rtol=1e-5)
            if previous is not None:
                if not torch.equal(previous[0], previous[1]):
                    raise RuntimeError("returned continuation overwritten by replay")
            previous = update.next_state, update.next_state.clone()
            print(json.dumps({"mode":mode,"update":index+1,"wallMs":times[-1],"loss":update.loss}),flush=True)
        if not torch.equal(cpu_rng,torch.random.get_rng_state()) or not torch.equal(gpu_rng,torch.cuda.get_rng_state(device)):
            raise RuntimeError("window execution changed RNG")
        result["runs"][mode] = {"updateWallMs":times,"warmedLast16MeanMs":sum(times[16:])/16,
                                "totalUpdateSeconds":sum(times)/1000,
                                "peakAllocatedBytes":torch.cuda.max_memory_allocated(device),
                                "peakReservedBytes":torch.cuda.max_memory_reserved(device),
                                "dispatch":trainer.window_execution.statistics()}
        del trainer, model, update, previous, adam, values
        torch.cuda.empty_cache()
    if sources != {name:sha(TRAINER / "pyrl_trainer" / name) for name in SOURCE_FILES}:
        raise RuntimeError("measured trainer source changed")
    destination = BASE / "native/target/qualified-cuda-window-padded-20261022.json"
    with destination.open("x",encoding="utf-8") as stream:
        json.dump(result,stream,indent=2)
    print(json.dumps({"result":str(destination),"maxAbs":result["maxAbs"]}),flush=True)


if __name__ == "__main__":
    main()
